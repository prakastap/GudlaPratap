Please find the assignment questions in the .ipynb file.

To access it, launch jupyter notebook and from it's front page, click on upload.

Now, select this particular exercise file and load it.

You can start solving the questions. This assignment must be solved by every attendee and submitted on or before the due dates that are mentioned on the LMS.