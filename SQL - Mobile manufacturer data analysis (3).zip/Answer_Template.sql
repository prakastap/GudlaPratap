--SQL Advance Case Study


--Q1--BEGIN 
	





--Q1--END

--Q2--BEGIN
	









--Q2--END

--Q3--BEGIN      
	










--Q3--END

--Q4--BEGIN







--Q4--END

--Q5--BEGIN














--Q5--END

--Q6--BEGIN












--Q6--END
	
--Q7--BEGIN  
	
	
















--Q7--END	
--Q8--BEGIN



















--Q8--END
--Q9--BEGIN
	

















--Q9--END

--Q10--BEGIN
	


















--Q10--END
	